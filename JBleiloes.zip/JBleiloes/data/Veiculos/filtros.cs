namespace JBleiloes.data.Veiculos
{
    public class MarcaCount
    {
        public string Marca { get; set; }
        public int Count { get; set; }
    }

    public class AnoCount
    {
        public int Ano { get; set; }
        public int Count { get; set; }
    }

    public class ModeloCount
    {
        public string Modelo { get; set; }
        public int Count { get; set; }
    }
}